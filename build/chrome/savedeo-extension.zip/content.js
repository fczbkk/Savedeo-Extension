chrome.extension.sendMessage({
  what: 'showIcon'
});
